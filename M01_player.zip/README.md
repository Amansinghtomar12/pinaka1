# M01 — Ahalya: The Petrified Memory

*In Mithila, on the road to Janaka's court, Vishvamitra brings Rama to a hermitage gone to
stone. Here the sage Gautama, betrayed, cursed his wife Ahalya to lie petrified — neither
living nor gone — her memory frozen at the instant of the curse. But stone remembers badly.
Over the long years the curse wrote and rewrote her, layer upon layer: half-formed versions,
abandoned recollections, whole stretches scoured away by the same power that froze her. One
true memory remains beneath it all — the last she truly held — and only that one, read back
whole, lets Rama's touch awaken her.*

You are handed the petrified archive: a dump of a fictional **persistent memory (NVM)** device
that was recording when the power was lost mid-write. Everything the device ever wrote is still
physically present, because it never overwrites in place — it writes each new version to a fresh
location and leaves the old ones behind. Many of those stale versions still pass their checksums.
Your task is to read back the **one genuine latest-committed record** for Ahalya's own memory
stone.

## What you are given

Three binary artifacts (all custom, undocumented formats — no schema is published):

| File | What it is |
|---|---|
| `archive.nvm` | The raw persistent-memory image: a flat array of fixed-size physical block frames, one per medium slot. Each frame carries a logical id, a version epoch, the transaction that wrote it, checksums, and a persistence seal. Older versions, abandoned writes and one interrupted (torn) write all coexist here. |
| `archive.log` | The device's write-ahead redo/undo log, appended after the last checkpoint. It records the transactions that changed records afterward. It is damaged: some records are torn and the tail was overwritten when the power failed. |
| `l2p.map`      | The logical-to-physical map checkpoint, plus the device geometry: the medium slot count and the wear-leveling scheme that scatters each logical block's physical address across the medium, a short relocation table, and the id of the sealed stone you must recover. |

Nothing in these files is random filler — the whole corpus is one internally consistent
recording of one device; unused medium slots are simply in the erased state. The flag is **not**
present in any file.

## Your goal

Recover the **single genuine latest-COMMITTED record** of the sealed logical id — the authentic
memory, not the obsolete, torn, or never-committed versions that still litter the medium. Reading
it back correctly means you had to: invert the wear-leveling indirection to translate a logical
physical-block-address into the medium slot that actually holds its bytes; reconcile the log
against the checkpoint, keeping only durable committed transactions and rolling back the losers;
reject the torn write the power loss left behind; and ignore the older-but-still-valid versions.

Present the record, with the facts you recovered along the way, to Gautama's seal (the validator)
for your instance. The seal checks your answer against the device's true history server-side and,
only on an exact match, returns the flag. There is exactly one record that passes; guessing will
not find it.

## Submission

`POST /ahalya/awaken` with a JSON body:

```json
{
  "target_lid": <int>,
  "committed_epoch": <int>,
  "committed_txn": <int>,
  "physical_slot": <int>,
  "record_digest": "<sha256 hex>",
  "committed_record_count": <int>,
  "archive_digest": "<sha256 hex>"
}
```

- **target_lid** — the sealed logical record id (as named in `l2p.map`).
- **committed_epoch** — the version number of the genuine latest-committed record.
- **committed_txn** — the transaction that committed it.
- **physical_slot** — the medium slot (frame index in `archive.nvm`) that holds that record,
  i.e. the slot you reach after inverting the wear-leveling indirection.
- **record_digest** — SHA-256 (hex) of that record's exact payload bytes.
- **committed_record_count** — how many live logical records are in the committed archive you
  reconstructed.
- **archive_digest** — a fingerprint of that whole reconstructed archive: for every live logical
  record, the string `lid:epoch:<sha256-hex-of-payload>`, sorted ascending by `lid`, joined with
  `;`, hashed with SHA-256 (hex).

All fields must be exactly right together. A record that looks plausible but rests on a version
the device never truly committed — or that was read without inverting the indirection — will be
refused.
